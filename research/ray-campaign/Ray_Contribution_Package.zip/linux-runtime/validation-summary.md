Ray controller replacement validation

Pinned source: `80142bad1d1db176f19c7e3aff6b6448631e66c2`

| Stage | Outcome |
| --- | --- |
| installed-packages | PASS |
| fixture-imports | PASS |
| haproxy-baseline | PASS |
| patch-check | PASS |
| patch-apply | PASS |
| haproxy-candidate | PASS |
| haproxy-comparison | PASS |
| long-poll-reconnect | PASS |
| long-poll-existing | PASS |
| changed-unit-tests | PASS |

Baseline PASS means the bug was reproduced; candidate PASS means the scoped recovery contract passed.
A setup failure or missing result is not evidence of recovery.
All required checks passed: true
