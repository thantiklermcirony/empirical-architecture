Ray candidate Linux lint: PASS

- buildifier: PASS
- buildifier-lint: PASS
- mypy: PASS
- pyrefly-serve: PASS
- docstyle: PASS
- ruff: PASS
- black: PASS
- pydoclint: PASS
- trailing-whitespace: PASS
- end-of-file-fixer: PASS
- check-ast: PASS

Uses the pinned upstream hook configuration on candidate files; no native Ray runtime or tests in this job.
