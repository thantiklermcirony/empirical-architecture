# Human review helper for the prepared environment on this workstation.
# Review Ray_Recovery.patch first. This script only verifies and runs tests;
# it does not submit a PR, sign anything, or attest that you understand the code.
$ErrorActionPreference = 'Stop'
$rayReviewWorkspace = 'C:/Users/madma/Documents/Codex/2026-09-09/ca'
$rayReviewPython = "$rayReviewWorkspace/work/ray-campaign/python/Scripts/python.exe"
if (-not (Test-Path -LiteralPath $rayReviewPython)) {
    throw 'Prepared environment is missing. Use the pinned Linux setup in the evidence package.'
}
$rayPriorPythonPath = $env:PYTHONPATH
$rayPriorUsageStats = $env:RAY_USAGE_STATS_ENABLED
Push-Location $rayReviewWorkspace
try {
    & $rayReviewPython -c "import ray, hashlib; from pathlib import Path; from ray.serve._private import long_poll, haproxy; assert ray.__commit__ == '80142bad1d1db176f19c7e3aff6b6448631e66c2'; assert hashlib.sha256(Path(long_poll.__file__).read_bytes()).hexdigest() == 'e7c696a1567800690f45ec1a2efe135d1060e98fabc57f294108adf29636c325'; assert hashlib.sha256(Path(haproxy.__file__).read_bytes()).hexdigest() == '4e47476c97505e4508169c7abaf8e86bae01de13f5a6a6fdbb2cb9b6caeaec28'; print('Verified candidate native runtime and implementation.')"
    if ($LASTEXITCODE -ne 0) { throw 'Candidate identity check failed' }
    $env:PYTHONPATH = "$rayReviewWorkspace/work/ray-campaign/research/regressions"
    $env:RAY_USAGE_STATS_ENABLED = '0'
    & $rayReviewPython -m pytest work/ray-campaign/research/regressions/test_long_poll_reconnect.py work/ray-campaign/ray/python/ray/serve/tests/unit/test_haproxy_manager_shutdown.py --import-mode=importlib --confcutdir=work/ray-campaign/ray/python/ray/serve/tests/unit -q --disable-warnings
    if ($LASTEXITCODE -ne 0) { throw 'Candidate tests failed' }
    Write-Output 'Tests completed. Human code review and understanding are separate from this result.'
}
finally {
    $env:PYTHONPATH = $rayPriorPythonPath
    $env:RAY_USAGE_STATS_ENABLED = $rayPriorUsageStats
    Pop-Location
}
